import logging
from binance.client import Client
from binance.enums import *

class BasicBot:
    def __init__(self, api_key, api_secret, testnet=True):
        self.api_key = api_key
        self.api_secret = api_secret
        self.testnet = testnet
        self.base_url = "https://testnet.binancefuture.com" if testnet else "https://fapi.binance.com"

        self.client = Client(api_key, api_secret)
        self.client.FUTURES_URL = self.base_url

        logging.basicConfig(
            filename='trading_bot.log',
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )

    def place_order(self, symbol, side, order_type, quantity, price=None, stop_price=None):
        try:
            if order_type == 'MARKET':
                order = self.client.futures_create_order(
                    symbol=symbol,
                    side=side,
                    type=ORDER_TYPE_MARKET,
                    quantity=quantity
                )
            elif order_type == 'LIMIT' and price:
                order = self.client.futures_create_order(
                    symbol=symbol,
                    side=side,
                    type=ORDER_TYPE_LIMIT,
                    timeInForce=TIME_IN_FORCE_GTC,
                    quantity=quantity,
                    price=price
                )
            elif order_type == 'STOP' and price and stop_price:
                order = self.client.futures_create_order(
                    symbol=symbol,
                    side=side,
                    type=ORDER_TYPE_STOP,
                    timeInForce=TIME_IN_FORCE_GTC,
                    price=price,
                    stopPrice=stop_price,
                    quantity=quantity
                )
            else:
                raise ValueError("Invalid order type or missing parameters.")

            logging.info(f"Order placed: {order}")
            print("✅ Order executed:", order)
            return order
        except Exception as e:
            logging.error(f"Error placing order: {str(e)}")
            print("❌ Error:", str(e))
            return None
