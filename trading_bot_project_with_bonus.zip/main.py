import getpass
from trading_bot import BasicBot
from binance.enums import *

def get_user_input():
    symbol = input("Enter trading pair (e.g., BTCUSDT): ").upper()
    side = input("Order side (BUY/SELL): ").upper()
    order_type = input("Order type (MARKET/LIMIT/STOP): ").upper()
    quantity = float(input("Quantity: "))
    price = None
    stop_price = None
    if order_type == "LIMIT":
        price = input("Enter Limit price: ")
    elif order_type == "STOP":
        stop_price = input("Enter Stop price: ")
        price = input("Enter Limit price: ")
    return symbol, side, order_type, quantity, price, stop_price

if __name__ == "__main__":
    print("Welcome to Binance Futures Trading Bot 🚀")

    api_key = getpass.getpass("Enter API Key: ")
    api_secret = getpass.getpass("Enter API Secret: ")

    bot = BasicBot(api_key, api_secret, testnet=True)

    symbol, side, order_type, quantity, price, stop_price = get_user_input()
    bot.place_order(symbol, side, order_type, quantity, price, stop_price)
